package com.example.bluetoothrealdemokt

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.w3c.dom.Text
import java.util.Timer

class MainActivity : AppCompatActivity() {
    private val REQUEST_BLUETOOTH_PERMISSION = 1
    private var bluetoothAdapter:BluetoothAdapter? = null


    //Toast Message 띄우기
    private fun showMessage(mainActivity: MainActivity, text: String) {
        println(text)
        Toast.makeText(this@MainActivity,"${text}",Toast.LENGTH_SHORT).show()
    }

    //앱 켤시 시작되는 부분
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val text01 = findViewById<TextView>(R.id.tvTest)

        //블루투스 권한 확인
        val bluetoothPermission = ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.BLUETOOTH
            )
        val bluetoothAdminPermission = ContextCompat.checkSelfPermission(
            this,
            android.Manifest.permission.BLUETOOTH_ADMIN
        )

        //블루투스를 지원하지 않는 장비면 강제종료
        if(1 == 2){
            showMessage(this,"블루투스를 지원하지 않는 기기 입니다.")
            finish() //종료

        }else { //블루투스 지원하면?
            //권한 요청
            checkPermission()
            requestBluetoothPermission()
            checkBluetoothState()
            Log.d("dazi","hello world")
            //showMessage(this,bluetoothAdapter.toString())
            //text01.text = bluetoothAdapter.toString()
            text01.text = "BLUETOOTH ${bluetoothPermission.toString()} , BLUETOOTH_ADMIN ${bluetoothAdminPermission.toString()}"
        }

    }

    private fun checkPermission(){
        var permission = mutableMapOf<String,String>()
        permission["BLUETOOTH"] = android.Manifest.permission.BLUETOOTH
        permission["BLUETOOTH_ADMIN"] = android.Manifest.permission.BLUETOOTH_ADMIN

        var denied = permission.count{ContextCompat.checkSelfPermission(this,it.value)==PackageManager.PERMISSION_DENIED}
        //마시멜로 버전 이후
        if(denied > 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            requestPermissions(permission.values.toTypedArray(),REQUEST_BLUETOOTH_PERMISSION)
        }
    }

    private fun requestBluetoothPermission(){
        val permissionsToRequest  = mutableListOf<String>()

        Log.d("dazi","${permissionsToRequest.toString()}")
        if (ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.BLUETOOTH
        ) != PackageManager.PERMISSION_GRANTED
        ){
            permissionsToRequest.add(android.Manifest.permission.BLUETOOTH)
        }
        if (ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.BLUETOOTH_ADMIN
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            permissionsToRequest.add(android.Manifest.permission.BLUETOOTH_ADMIN)
        }
        if(permissionsToRequest.isNotEmpty()){
            Log.d("dazi","${permissionsToRequest}")
            ActivityCompat.requestPermissions(
                this,
                permissionsToRequest.toTypedArray(),
                REQUEST_BLUETOOTH_PERMISSION
            )
        }

        Log.d("dazi","${permissionsToRequest.toString()}")
    }
    //블루투스 상태 체크 함수
    private fun checkBluetoothState(){
        bluetoothAdapter?.let{
            if(!it.isEnabled){
                showMessage(this,"블루투스를 켜주시기 바랍니다.")
            }else{
                showMessage(this,"블루투스가 활성화 되어 있습니다.")
            }
        }
    }


    }
}